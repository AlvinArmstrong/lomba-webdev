PR yang masih harus dikejar:
1. Responsive website
